﻿namespace RedistHeat
{
	public class CompAirTransmitter : CompAir
	{
	}
}
