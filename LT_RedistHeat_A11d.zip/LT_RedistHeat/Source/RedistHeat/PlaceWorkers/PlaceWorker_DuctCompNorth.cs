﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Verse;

namespace RedistHeat
{
	public class PlaceWorkerDuctCompNorth : PlaceWorker
	{
		public override void DrawGhost(ThingDef def, IntVec3 center, Rot4 rot)
		{
			var vecNorth = center + IntVec3.North.RotatedBy(rot);
			GenDraw.DrawFieldEdges(new List<IntVec3>() { vecNorth }, new Color(1f, 0.7f, 0f, 0.5f));
			var room = vecNorth.GetRoom();
			if (room == null || room.UsesOutdoorTemperature)
				return;
			GenDraw.DrawFieldEdges(room.Cells.ToList(), new Color(1f, 0.7f, 0f, 0.5f));
		}

		public override AcceptanceReport AllowsPlacing(BuildableDef checkingDef, IntVec3 loc, Rot4 rot)
		{
			var vecNorth = loc + IntVec3.North.RotatedBy(rot);
			if (!vecNorth.InBounds())
				return false;

			if (vecNorth.Impassable())
				return StaticSet.StringExposeDuct;

			return true;
		}
	}
}
