using RimWorld;
using Verse;
using Verse.AI;

namespace Hospitality
{
    public class WorkGiver_Recruiter : WorkGiver_Warden
    {
        private readonly JobDef jobDef = DefDatabase<JobDef>.GetNamed("GuestRecruit");

        public override Job JobOnThing(Pawn pawn, Thing t)
        {
            var guest = t as Pawn;
            if (!GuestUtility.ViableGuestTarget(guest) || guest.guest.interactionMode!=PrisonerInteractionMode.AttemptRecruit) return null;
            if (guest.BrokenStateDef != null
                || !pawn.CanReserveAndReach(guest, PathEndMode.OnCell, pawn.NormalMaxDanger()) 
                || !guest.Awake())
            {
                return null;
            }

            return new Job(jobDef, t);
        }
    }
}
