using RimWorld;
using Verse;
using Verse.AI;

namespace Hospitality
{
    public class WorkGiver_Diplomat : WorkGiver_Warden
    {
        private readonly JobDef jobDef = DefDatabase<JobDef>.GetNamed("GuestImproveRelationship");

        public override Job JobOnThing(Pawn pawn, Thing t)
        {
            var target = t as Pawn;
            if (!GuestUtility.ViableGuestTarget(target) || !target.ImproveRelationship()
                || target.Faction.ColonyGoodwill >= 100) return null;
            if (target.BrokenStateDef != null
                || !pawn.CanReserveAndReach(target, PathEndMode.OnCell, pawn.NormalMaxDanger()) || !target.Awake())
            {
                return null;
            }

            return new Job(jobDef, t);
        }
    }
}