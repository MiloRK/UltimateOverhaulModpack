using System;
using System.Collections.Generic;
using RimWorld;
using Verse;
using Verse.AI;

namespace Hospitality
{
    public class JobDriver_GuestImproveRelationship : JobDriver_GuestBase
    {
        private static readonly string txtRecruitSuccess = "MessageRecruitSuccess".Translate(); // from core
        private static readonly string txtRecruitFail = "MessageRecruitFail".Translate(); // from core
        private static readonly string txtRecruitFailMood = "RecruitFailMood".Translate();
        private static readonly string txtRecruitAngerSelfM = "RecruitAngerSelfM".Translate();
        private static readonly string txtRecruitAngerSelfF = "RecruitAngerSelfF".Translate();
        private static readonly string txtRecruitPleaseSelfM = "RecruitPleaseSelfM".Translate();
        private static readonly string txtRecruitPleaseSelfF = "RecruitPleaseSelfF".Translate();
        private static readonly string txtRecruitAngerOther = "RecruitAngerOther".Translate();
        private static readonly string txtImproveFactionAnger = "ImproveFactionAnger".Translate();
        private static readonly string txtImproveFactionPlease = "ImproveFactionPlease".Translate();
        
        private static readonly StatDef statOffendGuestChance = DefDatabase<StatDef>.GetNamed("OffendGuestChance");

        protected override IEnumerable<Toil> MakeNewToils()
        {
            yield return GotoGuest(pawn, Talkee, guest => guest.ImproveRelationship());
            yield return TryImproveRelationship(pawn, Talkee);
        }

        public static Toil TryImproveRelationship(Pawn recruiter, Pawn talkee)
        {
            var toil = new Toil
            {
                initAction = () => {
                    if (!GuestUtility.ViableGuestTarget(talkee)) return;
                    if (!talkee.ImproveRelationship()) return;
                    if (talkee.Faction.ColonyGoodwill >= 100) return;
                    if (!recruiter.CanTalkTo(talkee)) return;
                    recruiter.talker.TryTalkTo(new SpeechMessage(), talkee);
                },
                defaultCompleteMode = ToilCompleteMode.Delay,
                defaultDuration = 350,
                finishActions = new List<Action> {() => { var success = TryGuestImproveRelationship(recruiter, talkee); }}
            };
            toil.AddFailCondition(() => !GuestUtility.ViableGuestTarget(talkee) || !talkee.ImproveRelationship());
            return toil;
        }

        public static bool TryGuestImproveRelationship(Pawn recruiter, Pawn guest)
        {
            if (recruiter == null || guest == null || guest.guest == null) return false;

            recruiter.skills.Learn(SkillDefOf.Social, 25f);
            float chance = recruiter.GetStatValue(statOffendGuestChance);
            if (Rand.Value < chance)
            {
                //Log.Message("textAnger");
                Messages.Message(string.Format(txtImproveFactionAnger, recruiter.Nickname, guest.Faction.name, chance.ToStringPercent()), MessageSound.Standard);
                guest.Faction.AffectGoodwillWith(Faction.OfColony, -Rand.Range(3,8));
                guest.needs.mood.thoughts.TryGainThought(ThoughtDef.Named("GuestOffendedRelationship"));
                return false;
            }
            else
            {
                //Log.Message("textPlease");
                Messages.Message(string.Format(txtImproveFactionPlease, recruiter.Nickname, guest.Faction.name, (1 - chance).ToStringPercent()), MessageSound.Standard);
                guest.Faction.AffectGoodwillWith(Faction.OfColony, +1);
                guest.needs.mood.thoughts.TryGainThought(ThoughtDef.Named("GuestPleasedRelationship"));
                return true;
            }
        }
    }
}