using RimWorld;
using UnityEngine;
using Verse;

namespace Hospitality
{
    public class ITab_Pawn_Guest : ITab_Pawn_Visitor
    {
        private static readonly string txtRecruitmentDifficulty = "RecruitmentDifficulty".Translate(); // from core
        private static readonly string txtRecruitmentPenalty = "RecruitmentPenalty".Translate();

        public ITab_Pawn_Guest()
        {
            labelKey = "TabGuest";
            size = new Vector2(400f, 200f);
        }

        public override bool IsVisible
        {
            get { return GuestUtility.IsGuest(SelPawn); }
        }


        protected override void FillTab()
        {
            //ConceptDatabase.KnowledgeDemonstrated(ConceptDefOf.PrisonerTab, KnowledgeAmount.GuiFrame);
            Text.Font = GameFont.Small;
            Rect rect = new Rect(0f, 20f, size.x, size.y-20).ContractedBy(10f);
            var listingStandard = new Listing_Standard(rect);
            {
                var tryImprove = SelPawn.ImproveRelationship();
                var tryRecruit = SelPawn.TryRecruit();

                listingStandard.OverrideColumnWidth = size.x;
                listingStandard.DoLabelCheckbox("ShouldTryToRecruit".Translate(), ref tryRecruit);
                listingStandard.DoLabelCheckbox("ImproveRelationship".Translate(), ref tryImprove);
                listingStandard.DoLabel(txtRecruitmentDifficulty + ": " + MakeDifficultyRelative(SelPawn).ToString("##0"));
                listingStandard.DoLabel(txtRecruitmentPenalty + ": " + SelPawn.RecruitPenalty().ToString("##0"));
                listingStandard.DoLabel("Faction goodwill: " + SelPawn.Faction.ColonyGoodwill.ToString("##0"));

                SelPawn.guest.interactionMode = tryRecruit
                    ? PrisonerInteractionMode.AttemptRecruit
                    : tryImprove ? PrisonerInteractionMode.Chat 
                    : PrisonerInteractionMode.NoInteraction;
            }
            listingStandard.End();
        }

        private float MakeDifficultyRelative(Pawn guest)
        {
            const int maxStackingThoughts = 40;
            const float thoughtEffectivity = 2f;
            const float factor = 100/(maxStackingThoughts*thoughtEffectivity);
            return Mathf.Clamp((guest.guest.RecruitDifficulty - guest.needs.mood.CurLevel * 100)*factor, 0, 100);
        }
    }
}