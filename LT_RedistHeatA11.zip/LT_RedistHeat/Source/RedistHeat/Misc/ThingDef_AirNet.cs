﻿using Verse;
// ReSharper disable All

namespace RedistHeat
{
	public class ThingDef_AirNet : ThingDef
	{
		public bool isLockable = true;
	}
}
