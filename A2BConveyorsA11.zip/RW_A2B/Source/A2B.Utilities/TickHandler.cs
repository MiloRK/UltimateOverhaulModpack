using System;
namespace A2B.Utilities
{
	public class TickHandler
	{
	}
}
