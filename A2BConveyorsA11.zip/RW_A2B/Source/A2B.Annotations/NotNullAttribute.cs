using System;
namespace A2B.Annotations
{
	[AttributeUsage((AttributeTargets)6592, AllowMultiple = false, Inherited = true)]
	public sealed class NotNullAttribute : Attribute
	{
	}
}
