using System;
namespace A2B.Annotations
{
	[AttributeUsage(AttributeTargets.Method | AttributeTargets.Parameter)]
	public sealed class AspMvcPartialViewAttribute : PathReferenceAttribute
	{
	}
}
