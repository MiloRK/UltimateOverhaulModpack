using System;
namespace A2B.Annotations
{
	[AttributeUsage(AttributeTargets.Parameter)]
	public sealed class AspMvcModelTypeAttribute : Attribute
	{
	}
}
