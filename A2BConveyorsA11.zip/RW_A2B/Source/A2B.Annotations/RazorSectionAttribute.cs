using System;
namespace A2B.Annotations
{
	[AttributeUsage(AttributeTargets.Method | AttributeTargets.Parameter, Inherited = true)]
	public sealed class RazorSectionAttribute : Attribute
	{
	}
}
