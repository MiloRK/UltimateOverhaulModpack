using System;
namespace A2B.Annotations
{
	[AttributeUsage(AttributeTargets.Parameter)]
	public sealed class AspMvcAreaAttribute : PathReferenceAttribute
	{
		[NotNull]
		public string AnonymousProperty
		{
			get;
			private set;
		}
		public AspMvcAreaAttribute()
		{
		}
		public AspMvcAreaAttribute([NotNull] string anonymousProperty)
		{
			this.AnonymousProperty = anonymousProperty;
		}
	}
}
