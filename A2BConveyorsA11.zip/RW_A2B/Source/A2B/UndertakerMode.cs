using System;
namespace A2B
{
	public enum UndertakerMode
	{
		Undefined,
		PoweredLift,
		UnpoweredSlide
	}
}
