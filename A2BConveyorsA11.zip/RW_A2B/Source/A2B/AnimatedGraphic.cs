using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using Verse;
namespace A2B
{
	public class AnimatedGraphic : Graphic_Collection
	{
		private float animationRate = 1f;
		private bool isAnimating = true;
		private int defaultFrame;
		
		public bool IsAnimating
		{
			get
			{
				return this.isAnimating;
			}
			set
			{
				this.isAnimating = value;
			}
		}
		
		public int DefaultFrame
		{
			get
			{
				return this.defaultFrame;
			}
			set
			{
				this.defaultFrame = value;
			}
		}
		
		public Graphic DefaultGraphic
		{
			get
			{
				return this.subGraphics[this.DefaultFrame];
			}
		}
		
		public override Material MatSingle
		{
			get
			{
				return this.CurrentGraphic.MatSingle;
			}
		}
		
		public override Material MatFront
		{
			get
			{
				return this.CurrentGraphic.MatFront;
			}
		}
		
		public override Material MatSide
		{
			get
			{
				return this.CurrentGraphic.MatSide;
			}
		}
		
		public override Material MatBack
		{
			get
			{
				return this.CurrentGraphic.MatBack;
			}
		}
		
		public override bool ShouldDrawRotated
		{
			get
			{
				return true;
			}
		}
		
		public Graphic CurrentGraphic
		{
			get
			{
				return this.subGraphics[this.CurrentFrame];
			}
		}
		
		public int CurrentFrame
		{
			get
			{
				if (this.IsAnimating)
				{
					return (int)(Time.fixedTime * (float)this.subGraphics.Length / this.animationRate) % this.subGraphics.Length;
				}
				return 0;
			}
		}
		
		public static AnimatedGraphic FromSingleFrame(Graphic frame)
		{
			int length = frame.path.LastIndexOf('/');
			string text = frame.path.Substring(0, length);
			AnimatedGraphic animatedGraphic = (AnimatedGraphic)GraphicDatabase.Get<AnimatedGraphic>(text, frame.Shader, frame.drawSize, frame.color, frame.colorTwo);
			animatedGraphic.DefaultFrame = Array.FindIndex<Graphic>(animatedGraphic.subGraphics, (Graphic row) => row == frame);
			return animatedGraphic;
		}
		
		public override void Init(GraphicRequest req)
		{
			List<string> list = Directory.GetFiles(Path.Combine(ModUtilities.GetTexturePath(), req.path)).ToList<string>();
			list.Sort((string a, string b) => a.CompareTo(b));
			this.subGraphics = new Graphic_Single[list.Count];
			this.path = req.path;
			//this.shader = req.shader;
			this.color = req.color;
			this.drawSize = req.drawSize;
			int num = 0;
			foreach (string current in list)
			{
				string text = req.path + "/" + Path.GetFileNameWithoutExtension(current);
				this.subGraphics[num++] = GraphicDatabase.Get<Graphic_Single>(text, req.shader, this.drawSize, this.color);
			}
		}
		
		public override Graphic GetColoredVersion(Shader newShader, Color newColor, Color newColorTwo)
		{
			return this.CurrentGraphic.GetColoredVersion(newShader, newColor, newColorTwo);
		}
	}
}
