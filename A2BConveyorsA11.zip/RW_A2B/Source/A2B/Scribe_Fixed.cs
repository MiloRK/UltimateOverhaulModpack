using System;
using System.Collections.Generic;
using Verse;
namespace A2B
{
	public static class Scribe_Fixed
	{
		public static void LookDictionary<K, V>(ref Dictionary<K, V> dict, string dictLabel, LookMode keyLookMode = 0, LookMode valueLookMode = 0)
		{
			if (Scribe.mode == LoadSaveMode.PostLoadInit)
			{
				return;
			}
			Scribe.EnterNode(dictLabel);
			List<K> list = new List<K>();
			List<V> list2 = new List<V>();
			if (Scribe.mode == LoadSaveMode.Saving)
			{
				if (dict == null)
				{
					throw new ArgumentNullException("dict");
				}
				foreach (KeyValuePair<K, V> current in dict)
				{
					list.Add(current.Key);
					list2.Add(current.Value);
				}
			}
			Scribe_Collections.LookList<K>(ref list, "keys", keyLookMode, null);
			Scribe_Collections.LookList<V>(ref list2, "values", valueLookMode, null);
			if (Scribe.mode == LoadSaveMode.LoadingVars)
			{
				if (dict == null)
				{
					dict = new Dictionary<K, V>();
				}
				else
				{
					dict.Clear();
				}
				if (list != null && list2 != null)
				{
					for (int i = 0; i < list.Count; i++)
					{
						dict.Add(list[i], list2[i]);
					}
				}
			}
			Scribe.ExitNode();
		}
	}
}
