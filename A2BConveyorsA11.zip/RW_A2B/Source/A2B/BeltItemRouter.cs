using System;
using System.Collections.Generic;
using Verse;
namespace A2B
{
	public class BeltItemRouter
	{
		private BeltComponent _parent;
		private List<Rot4> _inputs = GeneralUtilities.List<Rot4>(new Rot4[]
		{
			Rot4.South
		});
		private List<Rot4> _outputs = GeneralUtilities.List<Rot4>(new Rot4[]
		{
			Rot4.North
		});
		public List<Rot4> Inputs
		{
			get
			{
				return this._inputs;
			}
		}
		public List<Rot4> Outputs
		{
			get
			{
				return this._outputs;
			}
		}
		public BeltComponent Parent
		{
			get
			{
				return this._parent;
			}
		}
		public BeltItemRouter(BeltComponent parent)
		{
			this._parent = parent;
		}
		public virtual Rot4 GetDirectionForItem(Thing thing, Rot4 inDir)
		{
			return Rot4.North;
		}
	}
}
