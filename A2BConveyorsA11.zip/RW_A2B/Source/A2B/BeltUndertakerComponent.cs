using RimWorld;
using System;
using System.Collections.Generic;
using UnityEngine;
using Verse;
namespace A2B
{
	public class BeltUndertakerComponent : BeltComponent
	{
		private float powerPerUndercover = 10f;
		private UndertakerMode operationMode;
		private bool forcedMode;
		private int undercoverCount;
		public BeltUndertakerComponent()
		{
			this._beltLevel = Level.Both;
			this.operationMode = UndertakerMode.Undefined;
			this.forcedMode = false;
			this.undercoverCount = 0;
		}
		public override void PostExposeData()
		{
			Scribe_Values.LookValue<UndertakerMode>(ref this.operationMode, "undertakerMode", UndertakerMode.Undefined, false);
			Scribe_Values.LookValue<bool>(ref this.forcedMode, "forcedMode", false, false);
			Scribe_Values.LookValue<int>(ref this.undercoverCount, "undercoversAttached", 0, false);
		}
		public override void PostSpawnSetup()
		{
			base.PostSpawnSetup();
			if (this.operationMode == UndertakerMode.PoweredLift && this.undercoverCount > 0)
			{
				base.PowerComponent.PowerOutput = -(base.PowerComponent.props.basePowerConsumption + (float)this.undercoverCount * this.powerPerUndercover);
			}
		}
		public override void OnOccasionalTick()
		{
			if (!this.forcedMode)
			{
				BeltComponent beltComponent = this.GetPositionFromRelativeRotation(Rot4.South).GetBeltComponent(Level.Surface);
				if (beltComponent != null)
				{
					if (beltComponent.CanAcceptFrom(this, true))
					{
						if (!this.IsLift())
						{
							this.ChangeOperationalMode(UndertakerMode.PoweredLift, false);
							return;
						}
						this.operationMode = UndertakerMode.PoweredLift;
					}
					else
					{
						if (!this.IsSlide())
						{
							this.ChangeOperationalMode(UndertakerMode.UnpoweredSlide, false);
							return;
						}
						this.operationMode = UndertakerMode.UnpoweredSlide;
					}
				}
			}
			if (this.operationMode == UndertakerMode.PoweredLift)
			{
				this.undercoverCount = this.CountUndercoversDirection(new Rot4((this.parent.Rotation.AsInt + Rot4.North.AsInt) % 4));
				base.PowerComponent.PowerOutput = -(base.PowerComponent.props.basePowerConsumption + (float)this.undercoverCount * this.powerPerUndercover);
				this.DoFreezeCheck();
			}
			else
			{
				BeltComponent beltComponent2 = null;
				Phase beltPhase = Phase.Offline;
				IntVec3 intVec = this.parent.Position;
				BeltComponent beltComponent3;
				do
				{
					intVec += this.parent.Rotation.FacingCell;
					beltComponent3 = intVec.GetBeltComponent(Level.Underground);
					if (beltComponent3 == null)
					{
						goto IL_10F;
					}
				}
				while (!beltComponent3.IsLift());
				beltComponent2 = beltComponent3;
				IL_10F:
				base.InferedPowerComponent = ((beltComponent2 == null) ? null : beltComponent2.PowerComponent);
				if (base.InferedPowerComponent != null && base.InferedPowerComponent.PowerOn)
				{
					beltPhase = Phase.Active;
				}
				this._beltPhase = beltPhase;
			}
			if (base.BeltPhase == Phase.Active || base.BeltPhase == Phase.Jammed)
			{
				this.DoJamCheck();
			}
		}
		private void ChangeOperationalMode(UndertakerMode newMode, bool forced = false)
		{
			string text;
			switch (newMode)
			{
			case UndertakerMode.PoweredLift:
				text = "A2BUndertaker";
				break;
			case UndertakerMode.UnpoweredSlide:
				text = "A2BSlide";
				break;
			default:
				return;
			}
			ThingDef named = DefDatabase<ThingDef>.GetNamed(text, true);
			IntVec3 position = this.parent.Position;
			Rot4 rotation = this.parent.Rotation;
			Thing thing = ThingMaker.MakeThing(named, null);
			thing.SetFactionDirect(Faction.OfColony);
			thing.HitPoints = this.parent.HitPoints;
			BeltUndertakerComponent beltUndertakerComponent = ThingCompUtility.TryGetComp<BeltUndertakerComponent>(thing);
			beltUndertakerComponent.forcedMode = forced;
			beltUndertakerComponent.operationMode = newMode;
			this.parent.Destroy(0);
			GenSpawn.Spawn(thing, position, rotation);
		}
		private int CountUndercoversDirection(Rot4 rot)
		{
			IntVec3 intVec = this.parent.Position;
			int num = 0;
			while (true)
			{
				intVec += rot.FacingCell;
				BeltComponent beltComponent = intVec.GetBeltComponent(Level.Underground);
				if (beltComponent == null || !beltComponent.IsUndercover())
				{
					break;
				}
				num++;
			}
			return num;
		}
		public override void OnItemTransfer(Thing item, BeltComponent other)
		{
			if (other.IsUndercover())
			{
				((BeltUndercoverComponent)other).outputDirection = this.parent.Rotation;
				((BeltUndercoverComponent)other).inputDirection = new Rot4((this.parent.Rotation.AsInt + 2) % 4);
			}
			if (Rand.Range(0f, 1f) < base.DeteriorateChance)
			{
				this.parent.TakeDamage(new DamageInfo(DamageDefOf.Deterioration, Rand.RangeInclusive(0, 2), this.parent, null, null));
			}
		}
		public override IntVec3 GetDestinationForThing(Thing thing)
		{
			if (this.operationMode == UndertakerMode.UnpoweredSlide)
			{
				return this.GetPositionFromRelativeRotation(Rot4.North);
			}
			if (this.operationMode == UndertakerMode.PoweredLift)
			{
				return this.GetPositionFromRelativeRotation(Rot4.South);
			}
			return this.GetPositionFromRelativeRotation(Rot4.South);
		}
		public override bool CanAcceptFrom(BeltComponent belt, bool onlyCheckConnection = false)
		{
			return (onlyCheckConnection || this.CanAcceptSomething()) && this.operationMode != UndertakerMode.Undefined && ((this.operationMode == UndertakerMode.UnpoweredSlide && belt.parent.Position == this.GetPositionFromRelativeRotation(Rot4.South)) || (this.operationMode == UndertakerMode.PoweredLift && belt.parent.Position == this.GetPositionFromRelativeRotation(Rot4.North)));
		}
		public override void PostDraw()
		{
			if (base.BeltPhase == Phase.Frozen)
			{
				this.DrawIceGraphic();
			}
			foreach (ThingStatus current in this.ItemContainer.ThingStatus)
			{
				Vector3 vector = this.parent.DrawPos + this.GetOffset(current);
				vector += -Altitudes.AltIncVect * this.parent.DrawPos.y + Altitudes.AltIncVect * (Altitudes.AltitudeFor(AltitudeLayer.Waist) + 0.03f);
				current.Thing.DrawAt(vector);
				BeltComponent.DrawGUIOverlay(current, vector);
			}
			if (this.operationMode == UndertakerMode.UnpoweredSlide && base.BeltPhase == Phase.Offline)
			{
				OverlayDrawer.DrawOverlay(this.parent, OverlayTypes.NeedsPower);
			}
		}
		protected override Vector3 GetOffset(ThingStatus status)
		{
			IntVec3 destinationForThing = this.GetDestinationForThing(status.Thing);
			float num = (float)status.Counter / (float)base.BeltSpeed;
			if (base.ThingOrigin == this.parent.Position - this.parent.Rotation.FacingCell)
			{
				if ((double)num < 0.5)
				{
					return (this.parent.Position - base.ThingOrigin).ToVector3() * (num - 0.5f);
				}
				return this.parent.Position.ToVector3();
			}
			else
			{
				if ((double)num < 0.5)
				{
					return this.parent.Position.ToVector3();
				}
				return (destinationForThing - this.parent.Position).ToVector3() * (num - 0.5f);
			}
		}
		public override string CompInspectStringExtra()
		{
			string str = Translator.Translate("A2B_Undertaker_Mode") + " ";
			switch (this.operationMode)
			{
			case UndertakerMode.Undefined:
				str += Translator.Translate("A2B_Undertaker_Mode_Undefined");
				break;
			case UndertakerMode.PoweredLift:
				str += Translator.Translate("A2B_Undertaker_Mode_PoweredLift");
				break;
			case UndertakerMode.UnpoweredSlide:
				str += Translator.Translate("A2B_Undertaker_Mode_UnpoweredSlide");
				break;
			default:
				throw new ArgumentOutOfRangeException();
			}
			if (this.operationMode != UndertakerMode.Undefined && this.forcedMode)
			{
				str = str + " (" + Translator.Translate("A2B_Forced") + ")";
			}
			return str + "\n" + base.CompInspectStringExtra();
		}
		public override IEnumerable<Command> CompGetGizmosExtra()
		{
			Command_Action command_Action = new Command_Action();
			if (command_Action != null)
			{
				command_Action.icon = ContentFinder<Texture2D>.Get("Ui/Icons/Commands/UndertakerMode", true);
				command_Action.defaultLabel = Translator.Translate("A2B_Undertaker_Mode_Toggle");
				command_Action.activateSound = SoundDef.Named("Click");
				if (this.operationMode == UndertakerMode.PoweredLift)
				{
					command_Action.defaultDesc = Translator.Translate("A2B_Undertaker_Mode_UnpoweredSlide");
					command_Action.action = delegate
					{
						this.ChangeOperationalMode(UndertakerMode.UnpoweredSlide, true);
					};
				}
				else
				{
					command_Action.defaultDesc = Translator.Translate("A2B_Undertaker_Mode_PoweredLift");
					command_Action.action = delegate
					{
						this.ChangeOperationalMode(UndertakerMode.PoweredLift, true);
					};
				}
				if (command_Action.action != null)
				{
					yield return command_Action;
				}
			}
			yield break;
		}
	}
}
