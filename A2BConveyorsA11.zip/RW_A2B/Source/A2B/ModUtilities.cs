using System;
using System.Linq;
using System.Reflection;
using UnityEngine;
using Verse;
namespace A2B
{
	public static class ModUtilities
	{
		public static Mod CurrentMod
		{
			get
			{
				Assembly asm = Assembly.GetExecutingAssembly();
				return LoadedModManager.LoadedMods.Single((Mod mod) => mod.assemblies.loadedAssemblies.Contains(asm));
			}
		}
		public static string GetTexturePath(this Mod mod)
		{
			return mod.RootFolder + "/" + GenFilePaths.ContentPath<Texture2D>();
		}
		public static string GetTexturePath()
		{
			return ModUtilities.CurrentMod.GetTexturePath();
		}
		public static string GetSoundPath(this Mod mod)
		{
			return mod.RootFolder + "/" + GenFilePaths.ContentPath<AudioClip>();
		}
		public static string GetSoundPath()
		{
			return ModUtilities.CurrentMod.GetSoundPath();
		}
		public static string GetStringPath(this Mod mod)
		{
			return mod.RootFolder + "/" + GenFilePaths.ContentPath<string>();
		}
		public static string GetStringPath()
		{
			return ModUtilities.CurrentMod.GetStringPath();
		}
	}
}
