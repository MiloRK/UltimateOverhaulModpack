using System;
namespace A2B
{
	public enum Phase
	{
		Offline,
		Active,
		Frozen,
		Jammed
	}
}
