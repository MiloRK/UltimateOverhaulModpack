using RimWorld;
using System;
using Verse;
namespace A2B
{
	public class Building_Teleporter : Building
	{
		private int prevFrame;
		public override Graphic Graphic
		{
			get
			{
				BeltComponent comp = base.GetComp<BeltComponent>();
				if (comp.BeltPhase == Phase.Active)
				{
					return base.Graphic;
				}
				AnimatedGraphic animatedGraphic = (AnimatedGraphic)base.Graphic;
				return animatedGraphic.DefaultGraphic;
			}
		}
		public override void SpawnSetup()
		{
			base.SpawnSetup();
			AnimatedGraphic animatedGraphic = (AnimatedGraphic)base.Graphic;
			animatedGraphic.DefaultFrame = 11;
		}
		public override void Tick()
		{
			base.Tick();
			base.GetComp<CompPowerTrader>();
			base.GetComp<BeltComponent>();
			if (this.Graphic.GetType() == typeof(AnimatedGraphic))
			{
				AnimatedGraphic animatedGraphic = (AnimatedGraphic)this.Graphic;
				if (animatedGraphic.CurrentFrame != this.prevFrame)
				{
					Find.MapDrawer.MapMeshDirty(base.Position, MapMeshFlag.Things, true, false);
					this.prevFrame = animatedGraphic.CurrentFrame;
				}
			}
		}
	}
}
