using A2B.Annotations;
using System;
using Verse;
namespace A2B
{
	public class ThingStatus
	{
		[NotNull]
		public Thing Thing
		{
			get;
			private set;
		}
		public int Counter
		{
			get;
			private set;
		}
		public ThingStatus([NotNull] Thing thing, int counter)
		{
			this.Thing = thing;
			this.Counter = counter;
		}
	}
}
