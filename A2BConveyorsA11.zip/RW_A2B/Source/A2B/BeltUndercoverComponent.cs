using RimWorld;
using System;
using Verse;
namespace A2B
{
	public class BeltUndercoverComponent : BeltComponent
	{
		public Rot4 inputDirection = Rot4.Invalid;
		public Rot4 outputDirection = Rot4.Invalid;
		public BeltUndercoverComponent()
		{
			this._beltLevel = Level.Underground;
		}
		public override void PostExposeData()
		{
			Scribe_Values.LookValue<Rot4>(ref this.inputDirection, "inputDirection", default(Rot4), false);
			Scribe_Values.LookValue<Rot4>(ref this.outputDirection, "outputDirection", default(Rot4), false);
		}
		public override void OnOccasionalTick()
		{
			BeltComponent beltComponent = null;
			Phase beltPhase = Phase.Offline;
			if (base.Empty)
			{
				int i = 0;
				while (i < 4)
				{
					Rot4 rot = new Rot4(i);
					IntVec3 intVec = this.parent.Position;
					while (true)
					{
						intVec += rot.FacingCell;
						BeltComponent beltComponent2 = intVec.GetBeltComponent(Level.Underground);
						if (beltComponent2 == null)
						{
							break;
						}
						if (beltComponent2.IsLift())
						{
							beltComponent = beltComponent2;
							if (beltComponent2.PowerComponent.PowerOn)
							{
								goto Block_4;
							}
						}
					}
					IL_61:
					i++;
					continue;
					Block_4:
					i += 4;
					goto IL_61;
				}
			}
			else
			{
				IntVec3 intVec2 = this.parent.Position;
				BeltComponent beltComponent3;
				do
				{
					intVec2 += this.outputDirection.FacingCell;
					beltComponent3 = intVec2.GetBeltComponent(Level.Underground);
					if (beltComponent3 == null)
					{
						goto IL_A6;
					}
				}
				while (!beltComponent3.IsLift());
				beltComponent = beltComponent3;
			}
			IL_A6:
			base.InferedPowerComponent = ((beltComponent == null) ? null : beltComponent.PowerComponent);
			if (base.InferedPowerComponent != null && base.InferedPowerComponent.PowerOn)
			{
				beltPhase = Phase.Active;
			}
			this._beltPhase = beltPhase;
			base.OnOccasionalTick();
		}
		public override IntVec3 GetDestinationForThing(Thing thing)
		{
			return this.GetPositionFromRelativeRotation(this.outputDirection);
		}
		public override void OnItemTransfer(Thing item, BeltComponent other)
		{
			if (other.IsUndercover())
			{
				((BeltUndercoverComponent)other).outputDirection = this.outputDirection;
				((BeltUndercoverComponent)other).inputDirection = this.inputDirection;
			}
			if (Rand.Range(0f, 1f) < base.DeteriorateChance)
			{
				this.parent.TakeDamage(new DamageInfo(DamageDefOf.Deterioration, Rand.RangeInclusive(0, 2), this.parent, null, null));
			}
			this.inputDirection = Rot4.Invalid;
			this.outputDirection = Rot4.Invalid;
		}
		public override bool CanAcceptFrom(BeltComponent belt, bool onlyCheckConnection = false)
		{
			return (onlyCheckConnection || this.CanAcceptSomething()) && (belt.IsUndercover() || belt.IsUndertaker());
		}
		private string RotationName(Rot4 r)
		{
			if (r == Rot4.North)
			{
				return Translator.Translate("A2B_Direction_North");
			}
			if (r == Rot4.East)
			{
				return Translator.Translate("A2B_Direction_East");
			}
			if (r == Rot4.South)
			{
				return Translator.Translate("A2B_Direction_South");
			}
			if (r == Rot4.West)
			{
				return Translator.Translate("A2B_Direction_West");
			}
			return "Unknown (" + r.ToString() + ")";
		}
		public override void PostDraw()
		{
			if (base.BeltPhase == Phase.Frozen)
			{
				this.DrawIceGraphic();
			}
			if (base.BeltPhase == Phase.Offline)
			{
				OverlayDrawer.DrawOverlay(this.parent, OverlayTypes.NeedsPower);
			}
		}
		public override string CompInspectStringExtra()
		{
			string text = base.CompInspectStringExtra();
			if (!base.Empty)
			{
				if (text != "")
				{
					text += "\n";
				}
				string text2 = text;
				text = string.Concat(new string[]
				{
					text2,
					Translator.Translate("A2B_Undertaker_Flow"),
					" ",
					this.RotationName(this.inputDirection),
					" ",
					Translator.Translate("A2B_Undertaker_FlowTo"),
					" ",
					this.RotationName(this.outputDirection)
				});
			}
			return text;
		}
	}
}
