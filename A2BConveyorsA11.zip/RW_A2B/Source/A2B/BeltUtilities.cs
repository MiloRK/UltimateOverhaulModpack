using A2B.Annotations;
using RimWorld;
using System;
using System.Collections.Generic;
using UnityEngine;
using Verse;
using Verse.AI;
namespace A2B
{
	public static class BeltUtilities
	{
		private static Graphic _iceGraphic;
		public static Graphic IceGraphic
		{
			get
			{
				if (BeltUtilities._iceGraphic == null)
				{
					Color color = new Color(1f, 1f, 1f, 0.4f);
					BeltUtilities._iceGraphic = GraphicDatabase.Get<Graphic_Single>("Effects/ice_64", ShaderDatabase.MetaOverlay, Vector2.one, color);
				}
				return BeltUtilities._iceGraphic;
			}
		}
		
		public static void DrawIceGraphic(this BeltComponent belt)
		{
			BeltUtilities.IceGraphic.Draw(belt.parent.DrawPos, belt.parent.Rotation, belt.parent);
		}
		
		[CanBeNull]
		public static BeltComponent GetBeltComponent(this IntVec3 position, Level lookLevel = Level.Surface)
		{
			foreach (Thing current in Find.ThingGrid.ThingsListAt(position))
			{
				ThingWithComps thingWithComps = current as ThingWithComps;
				if (thingWithComps != null)
				{
					BeltComponent beltComponent = ThingCompUtility.TryGetComp<BeltComponent>(thingWithComps);
					if (beltComponent != null && (lookLevel & beltComponent.BeltLevel) != (Level)0)
					{
						return beltComponent;
					}
				}
			}
			return null;
		}
		
		public static bool CanPlaceThing(this IntVec3 position, [NotNull] Thing thing)
		{
			PlaceSpotQuality placeSpotQuality = PlaceSpotQualityAt(position, thing, position);
			if (placeSpotQuality >= PlaceSpotQuality.Bad)
			{
				return true;
			}
			ISlotGroupParent slotGroupParent = Find.ThingGrid.ThingAt(position, ThingCategory.Building) as ISlotGroupParent;
			return slotGroupParent != null && slotGroupParent.GetStoreSettings().AllowedToAccept(thing);
		}
		
		private enum PlaceSpotQuality : byte
		{
			Unusable,
			Awful,
			Bad,
			Okay,
			Perfect
		}
		
		private static PlaceSpotQuality PlaceSpotQualityAt(IntVec3 c, Thing thing, IntVec3 center)
		{
			if (!c.InBounds() || !c.Walkable()) {
				return PlaceSpotQuality.Unusable;
			}
			List<Thing> list = Find.ThingGrid.ThingsListAt(c);
			int i = 0;
			while (i < list.Count) {
				Thing thing2 = list[i];
				if (thing.def.saveCompressible && thing2.def.saveCompressible) {
					return PlaceSpotQuality.Unusable;
				}
				if (thing2.def.category == ThingCategory.Item) {
					if (thing2.def == thing.def && thing2.stackCount < thing.def.stackLimit) {
						return PlaceSpotQuality.Perfect;
					}
					return PlaceSpotQuality.Unusable;
				}
				else {
					i++;
				}
			}
			if (c.GetRoom() == center.GetRoom()) {
				PlaceSpotQuality placeSpotQuality = PlaceSpotQuality.Perfect;
				for (int j = 0; j < list.Count; j++) {
					Thing thing3 = list[j];
					if (thing3.def.thingClass == typeof(Building_Door)) {
						return PlaceSpotQuality.Bad;
					}
					Pawn pawn = thing3 as Pawn;
					if (pawn != null) {
						if (pawn.Downed) {
							return PlaceSpotQuality.Bad;
						}
						if (placeSpotQuality > PlaceSpotQuality.Okay) {
							placeSpotQuality = PlaceSpotQuality.Okay;
						}
					}
					if (thing3.def.category == ThingCategory.Plant && thing3.def.selectable && placeSpotQuality > PlaceSpotQuality.Okay) {
						placeSpotQuality = PlaceSpotQuality.Okay;
					}
				}
				return placeSpotQuality;
			}
			if (!center.CanReach(c, PathEndMode.OnCell, TraverseMode.PassDoors, Danger.Deadly)) {
				return PlaceSpotQuality.Awful;
			}
			return 	PlaceSpotQuality.Bad;
		}
		
		public static IntVec3 GetPositionFromRelativeRotation(this BeltComponent belt, Rot4 rotation)
		{
			Rot4 rot = new Rot4((belt.parent.Rotation.AsInt + rotation.AsInt) % 4);
			return belt.parent.Position + rot.FacingCell;
		}
		
		public static float FreezeChance(this BeltComponent belt, float currentTemp)
		{
			float num = belt.FreezeTemperature - currentTemp;
			if (num < 0f)
			{
				return 0f;
			}
			if (num >= 20f)
			{
				return 1f;
			}
			float x = MathUtilities.LinearTransformInv(num, 0f, 20f);
			return MathUtilities.LinearTransform(x, 0.2f, 1f);
		}
		
		public static float JamChance(this BeltComponent belt, float health)
		{
			float num = 1f - health;
			if (num < 0.4f)
			{
				return 0f;
			}
			if (num >= 10f)
			{
				return 1f;
			}
			float x = MathUtilities.LinearTransformInv(num, 0f, 10f);
			return MathUtilities.LinearTransform(x, 0.01f, 1f);
		}
	}
}
