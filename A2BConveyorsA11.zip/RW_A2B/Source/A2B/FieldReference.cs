using System;
using System.Reflection;
namespace A2B
{
	public class FieldReference<T>
	{
		private object obj;
		private FieldInfo field;
		public T Value
		{
			get
			{
				return (T)((object)this.field.GetValue(this.obj));
			}
			set
			{
				this.field.SetValue(this.obj, value);
			}
		}
		public FieldReference(object obj, FieldInfo field)
		{
			this.obj = obj;
			this.field = field;
		}
		public static implicit operator T(FieldReference<T> fref)
		{
			return fref.Value;
		}
	}
}
