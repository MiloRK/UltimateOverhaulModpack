using System;
using System.Reflection;
namespace A2B
{
	public class PropertyReference<T>
	{
		private object obj;
		private PropertyInfo property;
		public T Value
		{
			get
			{
				return (T)((object)this.property.GetValue(this.obj, null));
			}
			set
			{
				this.property.SetValue(this.obj, value, null);
			}
		}
		public PropertyReference(object obj, PropertyInfo property)
		{
			this.obj = obj;
			this.property = property;
		}
		public static implicit operator T(PropertyReference<T> pref)
		{
			return pref.Value;
		}
	}
}
