using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Verse;
namespace A2B
{
	public class BeltTeleporterComponent : BeltComponent
	{
		private IntVec3 ReceiverPos;
		private static List<BeltTeleporterComponent> Receivers = new List<BeltTeleporterComponent>();
		private static List<BeltTeleporterComponent> Teleporters = new List<BeltTeleporterComponent>();
		private static float basePowerConsumption = 0f;
		private float DegreesPerDistance
		{
			get
			{
				if ("A2B_TeleporterHeat".IsResearched())
				{
					return 0.5f * this.props.heatPushMaxTemperature;
				}
				return this.props.heatPushMaxTemperature;
			}
		}
		protected override void DoFreezeCheck()
		{
		}
		public override void PostSpawnSetup()
		{
			base.PostSpawnSetup();
			if (!this.IsReceiver())
			{
				base.BeltSpeed = 270;
				BeltTeleporterComponent.Teleporters.Add(this);
				if (BeltTeleporterComponent.basePowerConsumption == 0f)
				{
					BeltTeleporterComponent.basePowerConsumption = base.PowerComponent.PowerOutput;
				}
				this.GetReceiverPos();
				return;
			}
			if (BeltTeleporterComponent.basePowerConsumption == 0f)
			{
				BeltTeleporterComponent.basePowerConsumption = base.PowerComponent.PowerOutput;
			}
			BeltTeleporterComponent.Receivers.Add(this);
			BeltTeleporterComponent.Teleporters.ForEach(delegate(BeltTeleporterComponent e)
			{
				e.GetReceiverPos();
			});
		}
		private void GetReceiverPos()
		{
			List<BeltTeleporterComponent> list = new List<BeltTeleporterComponent>();
			switch (this.parent.Rotation.AsInt)
			{
			case 0:
				list = (
					from e in BeltTeleporterComponent.Receivers
					where e.parent.Position.x == this.parent.Position.x && e.parent.Rotation.AsInt == 0 && e.parent.Position.z > this.parent.Position.z
					orderby e.parent.Position.z
					select e).ToList<BeltTeleporterComponent>();
				break;
			case 1:
				list = (
					from e in BeltTeleporterComponent.Receivers
					where e.parent.Position.z == this.parent.Position.z && e.parent.Rotation.AsInt == 1 && e.parent.Position.x > this.parent.Position.x
					orderby e.parent.Position.x
					select e).ToList<BeltTeleporterComponent>();
				break;
			case 2:
				list = (
					from e in BeltTeleporterComponent.Receivers
					where e.parent.Position.x == this.parent.Position.x && e.parent.Rotation.AsInt == 2 && e.parent.Position.z < this.parent.Position.z
					orderby e.parent.Position.z descending
					select e).ToList<BeltTeleporterComponent>();
				break;
			case 3:
				list = (
					from e in BeltTeleporterComponent.Receivers
					where e.parent.Position.z == this.parent.Position.z && e.parent.Rotation.AsInt == 3 && e.parent.Position.x < this.parent.Position.x
					orderby e.parent.Position.x descending
					select e).ToList<BeltTeleporterComponent>();
				break;
			}
			if (list.Count > 0)
			{
				this.ReceiverPos = list[0].parent.Position;
				base.PowerComponent.PowerOutput = (Vector3.Distance(this.ReceiverPos.ToVector3(), this.parent.Position.ToVector3()) * BeltTeleporterComponent.basePowerConsumption);
				return;
			}
			this.ReceiverPos = IntVec3.Zero;
			base.PowerComponent.PowerOutput = (BeltTeleporterComponent.basePowerConsumption);
		}
		public override IntVec3 GetDestinationForThing(Thing thing)
		{
			if (this.IsReceiver())
			{
				return base.GetDestinationForThing(thing);
			}
			return this.ReceiverPos;
		}
		public override bool CanAcceptFrom(BeltComponent belt, bool onlyCheckConnection = false)
		{
			if (this.IsReceiver())
			{
				return belt.IsTeleporter() && belt.parent.Rotation == this.parent.Rotation && ((BeltTeleporterComponent)belt).ReceiverPos == this.parent.Position;
			}
			return base.CanAcceptFrom(belt, onlyCheckConnection);
		}
		public override void PostDraw()
		{
			foreach (ThingStatus current in this.ItemContainer.ThingStatus)
			{
				Vector3 drawPos = this.parent.DrawPos;
				Vector3 vector = this.parent.RotatedSize.ToVector3();
				switch (this.parent.Rotation.AsInt)
				{
				case 0:
					drawPos = new Vector3(this.parent.DrawPos.x - 0.5f * (vector.x - 1f), this.parent.DrawPos.y, this.parent.DrawPos.z - 0.5f * (vector.z - 1f));
					break;
				case 1:
					drawPos = new Vector3(this.parent.DrawPos.x - 0.5f * (vector.x - 1f), this.parent.DrawPos.y, 1f + (this.parent.DrawPos.z - 0.5f * (vector.z - 1f)));
					break;
				case 2:
					if (!this.IsReceiver())
					{
						drawPos = new Vector3(this.parent.DrawPos.x - 0.5f * (vector.x - 1f) + 1f, this.parent.DrawPos.y, 1f + (this.parent.DrawPos.z - 0.5f * (vector.z - 1f)));
					}
					else
					{
						drawPos = new Vector3(this.parent.DrawPos.x - 0.5f * (vector.x - 1f) + 1f, this.parent.DrawPos.y, this.parent.DrawPos.z - 0.5f * (vector.z - 1f));
					}
					break;
				case 3:
					if (!this.IsReceiver())
					{
						drawPos = new Vector3(this.parent.DrawPos.x - 0.5f * (vector.x - 1f) + 1f, this.parent.DrawPos.y, this.parent.DrawPos.z - 0.5f * (vector.z - 1f));
					}
					else
					{
						drawPos = new Vector3(this.parent.DrawPos.x - 0.5f * (vector.x - 1f), this.parent.DrawPos.y, this.parent.DrawPos.z - 0.5f * (vector.z - 1f));
					}
					break;
				}
				Vector3 vector2 = drawPos + this.GetOffset(current) + Altitudes.AltIncVect * Altitudes.AltitudeFor(AltitudeLayer.Item);
				current.Thing.DrawAt(vector2);
				BeltComponent.DrawGUIOverlay(current, vector2);
			}
		}
		protected override Vector3 GetOffset(ThingStatus status)
		{
			IntVec3 destinationForThing = this.GetDestinationForThing(status.Thing);
			IntVec3 intVec;
			IntVec3 intVec2;
			if (base.ThingOrigin != IntVec3.Invalid && !this.IsReceiver())
			{
				intVec = destinationForThing - base.ThingOrigin;
				intVec2 = this.parent.Position + this.parent.Rotation.FacingCell - base.ThingOrigin;
			}
			else if (!this.IsReceiver())
			{
				intVec = new IntVec3(3 * this.parent.Rotation.FacingCell.x, this.parent.Rotation.FacingCell.y, 3 * this.parent.Rotation.FacingCell.z);
				intVec2 = this.parent.Rotation.FacingCell;
			}
			else
			{
				intVec = this.parent.Rotation.FacingCell;
				intVec2 = this.parent.Rotation.FacingCell;
			}
			float num = (float)status.Counter / (float)base.BeltSpeed;
			if (this.IsReceiver())
			{
				Vector3 vector = intVec.ToVector3();
				return vector * num * 0.5f;
			}
			if ((double)num < 0.5)
			{
				Vector3 vector2 = intVec2.ToVector3();
				Vector3 vector3 = new Vector3(0.5f * vector2.normalized.x, 0f, 0.5f * vector2.normalized.z);
				Vector3 vector4 = vector2.normalized + vector3;
				float num2 = num / 0.5f;
				return vector4 * num2 - vector3;
			}
			float num3 = Rand.Range(0f, 1f);
			if (num3 > 2f * (num - 0.5f))
			{
				Vector3 result = intVec2.ToVector3();
				result.Normalize();
				return result;
			}
			Vector3 vector5 = intVec.ToVector3();
			Vector3 vector6 = intVec.ToVector3();
			vector6.Normalize();
			return vector5 - vector6;
		}
		public override void PostDeSpawn()
		{
			BeltTeleporterComponent.Receivers.Remove(this);
			BeltTeleporterComponent.Teleporters.ForEach(delegate(BeltTeleporterComponent e)
			{
				e.GetReceiverPos();
			});
			base.PostDeSpawn();
		}
		public override void OnItemTransfer(Thing item, BeltComponent other)
		{
			if (this.IsReceiver())
			{
				return;
			}
			int num = "A2B_TeleporterHeat".IsResearched() ? 1 : 4;
			int num2 = "A2B_TeleporterHeat".IsResearched() ? 2 : 6;
			float num3 = base.PowerComponent.PowerOutput / BeltTeleporterComponent.basePowerConsumption * this.DegreesPerDistance;
			Room room = GridsUtility.GetRoom(this.parent.Position);
			if (room != null)
			{
				room.PushHeat(num3);
			}
			for (int i = 0; i < Rand.RangeInclusive(num, num2); i++)
			{
				MoteThrower.ThrowAirPuffUp(this.parent.DrawPos);
			}
			room = GridsUtility.GetRoom(this.ReceiverPos);
			if (room != null)
			{
				room.PushHeat(num3);
			}
			for (int j = 0; j < Rand.RangeInclusive(num, num2); j++)
			{
				MoteThrower.ThrowAirPuffUp(Gen.TrueCenter(this.ReceiverPos, this.parent.Rotation, new IntVec2(2, 1), 0.5f));
			}
		}
	}
}
