using A2B.Annotations;
using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using Verse;
using Verse.Sound;
namespace A2B
{
	public class BeltItemContainer : IExposable, IThingContainerGiver
	{
		private readonly BeltComponent _parentComponent;
		private readonly Dictionary<Thing, int> _thingCounter;
		private ThingContainer _container;
		
		[NotNull]
		public IEnumerable<Thing> Contents
		{
			get
			{
				return this._container.Contents;
			}
		}
		
		[NotNull]
		public IEnumerable<Thing> ThingsToMove
		{
			get
			{
				return (
					from pair in this._thingCounter
					where pair.Value >= this._parentComponent.BeltSpeed
					select pair.Key).ToList<Thing>();
			}
		}
		
		public bool WorkToDo
		{
			get
			{
				return this._thingCounter.Any((KeyValuePair<Thing, int> pair) => pair.Value >= this._parentComponent.BeltSpeed);
			}
		}
		
		public bool Empty
		{
			get
			{
				return this._container.Empty;
			}
		}
		
		[NotNull]
		public IEnumerable<ThingStatus> ThingStatus
		{
			get
			{
				return 
					from thing in this._container.Contents
					select new ThingStatus(thing, this._thingCounter[thing]);
			}
		}
		
		public BeltItemContainer([NotNull] BeltComponent component)
		{
			this._parentComponent = component;
			this._container = new ThingContainer(this);
			this._thingCounter = new Dictionary<Thing, int>();
		}
		
		public void ExposeData()
		{
			Scribe_Deep.LookDeep<ThingContainer>(ref this._container, "container");
			if (Scribe.mode == LoadSaveMode.LoadingVars)
			{
				Dictionary<string, int> dictionary = null;
				Scribe_Fixed.LookDictionary<string, int>(ref dictionary, "thingCounter", LookMode.Value, 0);
				this._thingCounter.Clear();
				if (dictionary == null)
				{
					return;
				}
				using (Dictionary<string, int>.Enumerator enumerator = dictionary.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						KeyValuePair<string, int> pair = enumerator.Current;
						Thing thing = this._container.Contents.FirstOrDefault(delegate(Thing t)
						{
							string arg_14_0 = t.ThingID;
							KeyValuePair<string, int> pair2 = pair;
							return arg_14_0 == pair2.Key;
						});
						if (thing != null)
						{
							Dictionary<Thing, int> arg_96_0 = this._thingCounter;
							Thing arg_96_1 = thing;
							KeyValuePair<string, int> pair3 = pair;
							arg_96_0.Add(arg_96_1, pair3.Value);
						}
					}
					return;
				}
			}
			if (Scribe.mode == LoadSaveMode.Saving)
			{
				Dictionary<string, int> dictionary2 = this._thingCounter.ToDictionary((KeyValuePair<Thing, int> pair) => pair.Key.ThingID, (KeyValuePair<Thing, int> pair) => pair.Value);
				Scribe_Fixed.LookDictionary<string, int>(ref dictionary2, "thingCounter", LookMode.Value, 0);
			}
		}
		
		[NotNull]
		public ThingContainer GetContainer()
		{
			return this._container;
		}
		
		public IntVec3 GetPosition()
    	{
			return this._container.owner.GetPosition();
    	}
		
		public void Tick()
		{
			this._container.ThingContainerTick();
			foreach (Thing current in this.Contents.Where(new Func<Thing, bool>(this.ShouldIncreaseCounter)))
			{
				Dictionary<Thing, int> thingCounter;
				Thing key;
				(thingCounter = this._thingCounter)[key = current] = thingCounter[key] + 1;
			}
		}
		
		private bool ShouldIncreaseCounter([NotNull] Thing thing)
		{
			int num = this._thingCounter[thing];
			if (num < this._parentComponent.BeltSpeed / 2 && !this._parentComponent.IsReceiver())
			{
				return true;
			}
			if (num >= this._parentComponent.BeltSpeed)
			{
				return false;
			}
			IntVec3 destinationForThing = this._parentComponent.GetDestinationForThing(thing);
			BeltComponent beltComponent = destinationForThing.GetBeltComponent(this._parentComponent.BeltLevel);
			if (beltComponent == null)
			{
				return this._parentComponent.CanOutputToNonBelt() && destinationForThing.CanPlaceThing(thing);
			}
			return beltComponent.CanAcceptFrom(this._parentComponent, false);
		}
		
		public bool AddItem([NotNull] Thing t, int initialCounter = 0)
		{
			if (!this._container.TryAdd(t))
			{
				return false;
			}
			this._thingCounter[t] = initialCounter;
			return true;
		}
		
		public void TransferItem([NotNull] Thing item, [NotNull] BeltItemContainer other)
		{
			this._container.Remove(item);
			this._thingCounter.Remove(item);
			other.AddItem(item, 0);
			this._parentComponent.OnItemTransfer(item, other._parentComponent);
		}
		
		public void DropItem([NotNull] Thing item, IntVec3 position, bool forced = false)
		{
			SoundDef soundDrop = item.def.soundDrop;
			try
			{
				item.def.soundDrop = null;
				if (this._container.Contains(item))
				{
					Thing thing;
					if (this._container.TryDrop(item, position, ThingPlaceMode.Direct, out thing) || forced)
					{
						if (forced && this._container.Contains(item) && !this._container.TryDrop(item, position, ThingPlaceMode.Near, out thing))
						{
							this._container.Remove(item);
							item.holder = null;
						}
						else
						{
							if (soundDrop != null)
							{
								SoundStarter.PlayOneShot(soundDrop, position);
							}
							this._thingCounter.Remove(item);
							item.holder = null;
							if (thing is ThingWithComps)
							{
								ForbidUtility.SetForbidden(thing, false, true);
							}
							if (thing.def.defName.Contains("Chunk") && Find.DesignationManager.DesignationOn(thing, DesignationDefOf.Haul) == null)
							{
								Find.DesignationManager.AddDesignation(new Designation(thing, DesignationDefOf.Haul));
							}
						}
					}
				}
			}
			finally
			{
				item.def.soundDrop = soundDrop;
			}
		}
		
		public void DropAll(IntVec3 position, bool forced = false)
		{
			foreach (Thing current in this._container.Contents.ToList<Thing>())
			{
				this.DropItem(current, position, forced);
			}
			this._thingCounter.Clear();
		}
		
		public void Destroy()
		{
			this.DropAll(this._parentComponent.parent.Position, true);
			this._container.DestroyContents();
		}
	}
}
