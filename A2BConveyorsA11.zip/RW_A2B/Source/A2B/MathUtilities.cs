using System;
namespace A2B
{
	public static class MathUtilities
	{
		public static float LinearTransform(float x, float min, float max)
		{
			return min + (max - min) * x;
		}
		public static float LinearTransformInv(float x, float min, float max)
		{
			return (x - min) / (max - min);
		}
	}
}
