using A2B.Annotations;
using RimWorld;
using System;
using System.Collections.Generic;
using UnityEngine;
using Verse;
namespace A2B
{
	[UsedImplicitly]
	public class BeltComponent : ThingComp
	{
		protected BeltItemContainer ItemContainer;
		protected Phase _beltPhase;
		private IntVec3 _thingOrigin;
		protected Level _beltLevel;
		
		public Phase BeltPhase
		{
			get
			{
				return this._beltPhase;
			}
		}
		
		public Level BeltLevel
		{
			get
			{
				return this._beltLevel;
			}
		}
		
		public CompGlower GlowerComponent
		{
			get;
			set;
		}
		
		public CompPowerTrader PowerComponent
		{
			get;
			set;
		}
		
		public CompPowerTrader InferedPowerComponent
		{
			get;
			set;
		}
		
		public int BeltSpeed
		{
			get;
			protected set;
		}
		
		protected IntVec3 ThingOrigin
		{
			get
			{
				return this._thingOrigin;
			}
			set
			{
				this._thingOrigin = value;
			}
		}
		
		public bool Empty
		{
			get
			{
				return this.ItemContainer.Empty;
			}
		}
		
		public float DeteriorateChance
		{
			get
			{
				if ("A2B_Durability".IsResearched())
				{
					return 0.025f;
				}
				return 0.05f;
			}
		}
		
		public float FreezeTemperature
		{
			get
			{
				if ("A2B_Climatization".IsResearched())
				{
					return this.props.minTargetTemperature - 20f;
				}
				return this.props.minTargetTemperature;
			}
		}
		
		public BeltComponent()
		{
			this._beltLevel = Level.Surface;
			this._beltPhase = Phase.Offline;
			this.ItemContainer = new BeltItemContainer(this);
			this.ThingOrigin = IntVec3.Invalid;
			this.BeltSpeed = 90;
		}
		
		protected virtual void DoFreezeCheck()
		{
			float temperatureForCell = GenTemperature.GetTemperatureForCell(this.parent.Position);
			if (this.BeltPhase == Phase.Frozen && temperatureForCell > this.FreezeTemperature && Rand.Range(0f, 1f) < 0.5f)
			{
				this._beltPhase = Phase.Offline;
			}
			if (this.BeltPhase != Phase.Frozen && Rand.Range(0f, 1f) < this.FreezeChance(temperatureForCell))
			{
				this.Freeze();
			}
		}
		
		protected virtual void Freeze()
		{
			this._beltPhase = Phase.Frozen;
			Messages.Message(Translator.Translate("A2B_Frozen_Message"), MessageSound.Negative);
			MoteThrower.ThrowMicroSparks(Gen.TrueCenter(this.parent));
		}
		
		public virtual IntVec3 GetDestinationForThing([NotNull] Thing thing)
		{
			return this.GetPositionFromRelativeRotation(Rot4.North);
		}
		
		public virtual bool CanAcceptFrom(BeltComponent belt, bool onlyCheckConnection = false)
		{
			if (!onlyCheckConnection && !this.CanAcceptSomething())
			{
				return false;
			}
			for (int i = 0; i < 4; i++)
			{
				Rot4 rot = new Rot4(i);
				if (this.CanAcceptFrom(rot) && belt.parent.Position == this.GetPositionFromRelativeRotation(rot))
				{
					return true;
				}
			}
			return false;
		}
		
		public virtual bool CanAcceptFrom(Rot4 direction)
		{
			return direction == Rot4.South;
		}
		
		public virtual bool CanAcceptSomething()
		{
			return this.Empty && this.BeltPhase == Phase.Active;
		}
		
		public virtual bool CanOutputToNonBelt()
		{
			return false;
		}
		
		protected virtual void MoveThingTo([NotNull] Thing thing, IntVec3 beltDest)
		{
			if (this.CanOutputToNonBelt() && Find.TerrainGrid.TerrainAt(beltDest).changeable)
			{
				this.ItemContainer.DropItem(thing, beltDest, false);
				return;
			}
			Level lookLevel = this.BeltLevel;
			if (this.BeltLevel == Level.Both)
			{
				if (this.IsLift())
				{
					lookLevel = Level.Surface;
				}
				else if (this.IsSlide())
				{
					lookLevel = Level.Underground;
				}
			}
			BeltComponent beltComponent = beltDest.GetBeltComponent(lookLevel);
			if (beltComponent == null || !beltComponent.ItemContainer.Empty || beltComponent.BeltPhase != Phase.Active)
			{
				return;
			}
			this.ItemContainer.TransferItem(thing, beltComponent.ItemContainer);
			beltComponent.ThingOrigin = this.parent.Position;
		}
		
		protected static void DrawGUIOverlay([NotNull] ThingStatus status, Vector3 drawPos)
		{
			CameraZoomRange? currentRange = Find.CameraMap.CurrentZoom;
			if (currentRange != null)
			{
				return;
			}
			drawPos.z -= 0.4f;
			Vector3 vector = Find.CameraMap.camera.WorldToScreenPoint(drawPos);
			vector.y = (float)Screen.height - vector.y;
			GenWorldUI.DrawThingLabel(new Vector2(vector.x, vector.y), GenString.ToStringCached(status.Thing.stackCount), new Color(1f, 1f, 1f, 0.75f));
		}
		
		protected virtual Vector3 GetOffset([NotNull] ThingStatus status)
		{
			IntVec3 destinationForThing = this.GetDestinationForThing(status.Thing);
			IntVec3 intVec;
			if (this.ThingOrigin != IntVec3.Invalid)
			{
				intVec = destinationForThing - this.ThingOrigin;
			}
			else
			{
				intVec = this.parent.Rotation.FacingCell;
			}
			float num = (float)status.Counter / (float)this.BeltSpeed;
			if (Math.Abs(intVec.x) == 1 && Math.Abs(intVec.z) == 1 && this.ThingOrigin != IntVec3.Invalid)
			{
				Vector3 vector = (this.parent.Position - this.ThingOrigin).ToVector3();
				Vector3 vector2 = (destinationForThing - this.parent.Position).ToVector3();
				vector = -vector / 2f;
				vector2 /= 2f;
				float num2 = num * 3.14159274f / 2f;
				float num3 = Mathf.Cos(num2);
				float num4 = Mathf.Sin(num2);
				return vector * (1f - num4) + vector2 * (1f - num3);
			}
			Vector3 vector3 = intVec.ToVector3();
			vector3.Normalize();
			float num5 = num - 0.5f;
			return vector3 * num5;
		}
		
		public override void PostDestroy(DestroyMode mode = 0)
		{
			this.ItemContainer.Destroy();
			base.PostDestroy(mode);
		}
		
		public override void PostSpawnSetup()
		{
			this.GlowerComponent = this.parent.GetComp<CompGlower>();
			this.PowerComponent = this.parent.GetComp<CompPowerTrader>();
			this.InferedPowerComponent = null;
			if (BeltUtilities.IceGraphic == null)
			{
				Log.ErrorOnce("IceGraphic was null!", 12);
			}
		}
		
		public override void PostExposeData()
		{
			Scribe_Values.LookValue<Phase>(ref this._beltPhase, "phase", Phase.Offline, false);
			Scribe_Deep.LookDeep<BeltItemContainer>(ref this.ItemContainer, "container", this);
			Scribe_Values.LookValue<IntVec3>(ref this._thingOrigin, "thingOrigin", IntVec3.Invalid, false);
		}
		
		public override void PostDraw()
		{
			base.PostDraw();
			if (this.BeltPhase == Phase.Frozen)
			{
				this.DrawIceGraphic();
			}
			foreach (ThingStatus current in this.ItemContainer.ThingStatus)
			{
				Vector3 vector = this.parent.DrawPos + this.GetOffset(current) + Altitudes.AltIncVect * Altitudes.AltitudeFor(AltitudeLayer.Item);
				current.Thing.DrawAt(vector);
				BeltComponent.DrawGUIOverlay(current, vector);
			}
		}
		
		public override void CompTick()
		{
			if ((Find.TickManager.TicksGame + this.GetHashCode()) % 300 == 0)
			{
				this.OnOccasionalTick();
			}
			if (this.BeltPhase == Phase.Frozen && (double)Rand.Range(0f, 1f) < 0.05)
			{
				MoteThrower.ThrowAirPuffUp(this.parent.DrawPos);
			}
			if (this.BeltPhase == Phase.Jammed && (double)Rand.Range(0f, 1f) < 0.05)
			{
				MoteThrower.ThrowMicroSparks(this.parent.DrawPos);
			}
			this.DoBeltTick();
			this.ItemContainer.Tick();
		}
		
		public virtual void OnOccasionalTick()
		{
			this.DoFreezeCheck();
			if (this.BeltPhase == Phase.Active || this.BeltPhase == Phase.Jammed)
			{
				this.DoJamCheck();
			}
		}
		
		protected virtual void PostItemContainerTick()
		{
		}
		
		public virtual void OnItemTransfer(Thing item, BeltComponent other)
		{
			if (Rand.Range(0f, 1f) < this.DeteriorateChance)
			{
				this.parent.TakeDamage(new DamageInfo(DamageDefOf.Deterioration, Rand.RangeInclusive(0, 2), this.parent, null, null));
			}
		}
		
		private void DoBeltTick()
		{
			CompPowerTrader compPowerTrader = this.PowerComponent;
			if (compPowerTrader == null)
			{
				compPowerTrader = this.InferedPowerComponent;
			}
			if (compPowerTrader == null)
			{
				return;
			}
			if (compPowerTrader.PowerOn)
			{
				if (this.BeltPhase == Phase.Offline)
				{
					this._beltPhase = Phase.Active;
					if (this.GlowerComponent != null)
					{
						this.GlowerComponent.Lit = true;
					}
					if (this._beltLevel == Level.Underground)
					{
						return;
					}
					foreach (Thing current in Find.Map.thingGrid.ThingsAt(this.parent.Position))
					{
						if (current.def.category == ThingCategory.Item && current != this.parent)
						{
							this.ItemContainer.AddItem(current, this.BeltSpeed / 2);
						}
					}
					return;
				}
				else
				{
					if (this.BeltPhase != Phase.Active)
					{
						return;
					}
					if (this.GlowerComponent != null)
					{
						this.GlowerComponent.Lit = true;
					}
					this.ItemContainer.Tick();
					this.PostItemContainerTick();
					if (!this.ItemContainer.WorkToDo)
					{
						return;
					}
					using (IEnumerator<Thing> enumerator2 = this.ItemContainer.ThingsToMove.GetEnumerator())
					{
						while (enumerator2.MoveNext())
						{
							Thing current2 = enumerator2.Current;
							IntVec3 destinationForThing = this.GetDestinationForThing(current2);
							this.MoveThingTo(current2, destinationForThing);
						}
						return;
					}
				}
			}
			if (this.BeltPhase != Phase.Active || (this.BeltLevel & Level.Surface) == (Level)0)
			{
				return;
			}
			if (this.GlowerComponent != null)
			{
				this.GlowerComponent.Lit = false;
			}
			this._beltPhase = Phase.Offline;
			this.ItemContainer.DropAll(this.parent.Position, true);
		}
		
		public virtual void DoJamCheck()
		{
			if (this.BeltPhase == Phase.Jammed && this.parent.HitPoints == this.parent.MaxHitPoints)
			{
				this._beltPhase = Phase.Offline;
				return;
			}
			if (this.BeltPhase == Phase.Active)
			{
				float health = (float)this.parent.HitPoints / (float)this.parent.MaxHitPoints;
				if ("A2B_Reliability".IsResearched() && Rand.Range(0f, 1f) < 0.5f)
				{
					return;
				}
				if (Rand.Range(0f, 1f) < this.JamChance(health))
				{
					this.Jam();
				}
			}
		}
		
		public virtual void Jam()
		{
			int num = Rand.RangeInclusive(1, 3);
			for (int i = 0; i < num; i++)
			{
				MoteThrower.ThrowMicroSparks(this.parent.DrawPos);
			}
			this._beltPhase = Phase.Jammed;
			Messages.Message(Translator.Translate("A2B_Jammed_Message"), MessageSound.Negative);
		}
		
		[NotNull]
		public override string CompInspectStringExtra()
		{
			string text = Translator.Translate("A2B_Status") + " ";
			switch (this.BeltPhase)
			{
			case Phase.Offline:
				text += Translator.Translate("A2B_Offline");
				break;
			case Phase.Active:
				text += Translator.Translate("A2B_Active");
				break;
			case Phase.Frozen:
				text += Translator.Translate("A2B_Frozen");
				break;
			case Phase.Jammed:
				text += Translator.Translate("A2B_Jammed");
				break;
			default:
				throw new ArgumentOutOfRangeException();
			}
			if (this.ItemContainer.Empty)
			{
				return text;
			}
			return string.Concat(new string[]
			{
				text,
				"\n",
				Translator.Translate("A2B_Contents"),
				" ",
				this.ItemContainer.GetContainer().ContentsString
			});
		}
	}
}
