using System;
using Verse;
namespace A2B
{
	public static class A2BResearch
	{
		public const string Climatization = "A2B_Climatization";
		public const string TeleporterHeat = "A2B_TeleporterHeat";
		public const string Durability = "A2B_Durability";
		public const string Reliability = "A2B_Reliability";
		public static bool IsResearched(this string name)
		{
			return Find.ResearchManager.IsFinished(ResearchProjectDef.Named(name));
		}
	}
}
