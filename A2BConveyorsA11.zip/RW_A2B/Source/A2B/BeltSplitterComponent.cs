using System;
using Verse;
namespace A2B
{
	public class BeltSplitterComponent : BeltComponent
	{
		private string _mythingID;
		private IntVec3 _splitterDest;
		public override IntVec3 GetDestinationForThing(Thing thing)
		{
			IntVec3[] array = new IntVec3[]
			{
				this.GetPositionFromRelativeRotation(Rot4.West),
				this.GetPositionFromRelativeRotation(Rot4.North),
				this.GetPositionFromRelativeRotation(Rot4.East)
			};
			int num = Math.Max(0, Array.FindIndex<IntVec3>(array, (IntVec3 dir) => dir == this._splitterDest));
			if (this._mythingID == thing.ThingID && this.IsFreeBelt(this._splitterDest))
			{
				return this._splitterDest;
			}
			this._mythingID = thing.ThingID;
			num = (num + 1) % 3;
			if (this.IsFreeBelt(array[num]))
			{
				this._splitterDest = array[num];
				return this._splitterDest;
			}
			num = (num + 1) % 3;
			if (this.IsFreeBelt(array[num]))
			{
				this._splitterDest = array[num];
				return this._splitterDest;
			}
			return this._splitterDest;
		}
		private bool IsFreeBelt(IntVec3 position)
		{
			BeltComponent beltComponent = position.GetBeltComponent(Level.Surface);
			return beltComponent != null && beltComponent.CanAcceptFrom(this, false);
		}
	}
}
