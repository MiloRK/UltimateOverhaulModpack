using System;
using Verse;
namespace A2B
{
	public class BeltCurveComponent : BeltComponent
	{
		public override IntVec3 GetDestinationForThing(Thing thing)
		{
			IntVec3 intVec = this.parent.Position - this.parent.Rotation.FacingCell;
			IntVec3 result = this.parent.Position + new IntVec3(-this.parent.Rotation.FacingCell.z, this.parent.Rotation.FacingCell.y, this.parent.Rotation.FacingCell.x);
			if (base.ThingOrigin != intVec)
			{
				return intVec;
			}
			return result;
		}
		public override bool CanAcceptFrom(Rot4 direction)
		{
			return direction == Rot4.South || direction == Rot4.West;
		}
	}
}
