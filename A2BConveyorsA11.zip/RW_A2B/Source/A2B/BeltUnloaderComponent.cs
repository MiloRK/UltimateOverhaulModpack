using System;
namespace A2B
{
	public class BeltUnloaderComponent : BeltComponent
	{
		public override bool CanOutputToNonBelt()
		{
			return true;
		}
		protected override void Freeze()
		{
		}
		public override void Jam()
		{
		}
	}
}
