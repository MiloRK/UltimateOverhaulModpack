using RimWorld;
using System;
using Verse;
namespace A2B
{
	public class BeltLoaderComponent : BeltComponent
	{
		private bool hasStorageSettings;
		public override void PostExposeData()
		{
			base.PostExposeData();
			Scribe_Values.LookValue<bool>(ref this.hasStorageSettings, "hasStorageSettings", false, false);
		}
		public override void PostSpawnSetup()
		{
			base.PostSpawnSetup();
			ISlotGroupParent slotGroupParent = this.parent as ISlotGroupParent;
			if (slotGroupParent == null)
			{
				throw new InvalidOperationException("parent is not an ISlotGroupParent!");
			}
			if (!this.hasStorageSettings)
			{
				slotGroupParent.GetStoreSettings().filter.SetDisallowAll();
			}
			this.hasStorageSettings = true;
		}
		protected override void Freeze()
		{
		}
		public override void Jam()
		{
		}
		public override bool CanAcceptSomething()
		{
			return false;
		}
		protected override void PostItemContainerTick()
		{
			foreach (Thing current in Find.ThingGrid.ThingsAt(this.parent.Position))
			{
				if (current.def.category == ThingCategory.Item && current != this.parent)
				{
					IntVec3 destinationForThing = this.GetDestinationForThing(current);
					BeltComponent beltComponent = destinationForThing.GetBeltComponent(Level.Surface);
					if (beltComponent != null && beltComponent.CanAcceptFrom(this, false))
					{
						this.ItemContainer.AddItem(current, base.BeltSpeed / 2);
					}
				}
			}
		}
	}
}
