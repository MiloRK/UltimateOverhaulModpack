using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
namespace A2B
{
	public static class GeneralUtilities
	{
		private const BindingFlags MasterKey = BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy;
		public static List<T> List<T>(params T[] seq)
		{
			return ((IEnumerable<T>)seq).ToList<T>();
		}
		public static object Call(this object obj, string methodName, params object[] args)
		{
			return obj.Call(methodName, args);
		}
		public static T Call<T>(this object obj, string methodName, params object[] args)
		{
			Type type = obj.GetType();
			MethodInfo method = type.GetMethod(methodName, BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy);
			return (T)((object)method.Invoke(obj, args));
		}
		public static object Call(this Type type, string methodName, params object[] args)
		{
			return type.Call(methodName, args);
		}
		public static T Call<T>(this Type type, string methodName, params object[] args)
		{
			MethodInfo method = type.GetMethod(methodName, BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy);
			return (T)((object)method.Invoke(null, args));
		}
		public static PropertyReference<object> Property(this object obj, string propertyName)
		{
			return obj.Property(propertyName);
		}
		public static PropertyReference<T> Property<T>(this object obj, string propertyName)
		{
			Type type = obj.GetType();
			PropertyInfo property = type.GetProperty(propertyName, BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy);
			return new PropertyReference<T>(obj, property);
		}
		public static PropertyReference<object> Property(this Type type, string propertyName)
		{
			return type.Property(propertyName);
		}
		public static PropertyReference<T> Property<T>(this Type type, string propertyName)
		{
			PropertyInfo property = type.GetProperty(propertyName, BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy);
			return new PropertyReference<T>(null, property);
		}
		public static FieldReference<object> Field(this object obj, string fieldName)
		{
			return obj.Field(fieldName);
		}
		public static FieldReference<T> Field<T>(this object obj, string fieldName)
		{
			Type type = obj.GetType();
			FieldInfo field = type.GetField(fieldName, BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy);
			return new FieldReference<T>(obj, field);
		}
		public static FieldReference<object> Field(this Type type, string fieldName)
		{
			return type.Field(fieldName);
		}
		public static FieldReference<T> Field<T>(this Type type, string fieldName)
		{
			FieldInfo field = type.GetField(fieldName, BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy);
			return new FieldReference<T>(null, field);
		}
	}
}
