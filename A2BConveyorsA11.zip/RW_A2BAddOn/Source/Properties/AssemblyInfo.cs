using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
[assembly: AssemblyVersion("0.10.0.0")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("Copyleft")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyFileVersion("0.10.0.0")]
[assembly: AssemblyProduct("A2B_Selector")]
[assembly: AssemblyTitle("A2B_Selector")]
[assembly: AssemblyTrademark("")]
[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: ComVisible(false)]
[assembly: Guid("81825217-fc85-4c56-b99e-fae5c1493efd")]
