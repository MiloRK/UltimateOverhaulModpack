using A2B;
using RimWorld;
using System;
using Verse;
namespace A2B_Selector
{
	public class Right : BeltComponent
	{
		private Rot4 nextDest = Rot4.West;
		private bool hasStorageSettings;
		private string _mythingID;
		private IntVec3 _splitterDest;
		public override void PostExposeData()
		{
			base.PostExposeData();
			Scribe_Values.LookValue<bool>(ref this.hasStorageSettings, "hasStorageSettings", false, false);
		}
		public override void PostSpawnSetup()
		{
			base.PostSpawnSetup();
			ISlotGroupParent slotGroupParent = this.parent as ISlotGroupParent;
			if (slotGroupParent == null)
			{
				throw new InvalidOperationException("parent is not a SlotGroupParent!");
			}
			if (!this.hasStorageSettings)
			{
				slotGroupParent.GetStoreSettings().filter.SetDisallowAll();
			}
			this.hasStorageSettings = true;
		}
		public override IntVec3 GetDestinationForThing(Thing thing)
		{
			ISlotGroupParent slotGroupParent = this.parent as ISlotGroupParent;
			if (slotGroupParent == null)
			{
				throw new InvalidOperationException("parent is not a SlotGroupParent!");
			}
			StorageSettings storeSettings = slotGroupParent.GetStoreSettings();
			if (storeSettings.AllowedToAccept(thing))
			{
				return this.GetPositionFromRelativeRotation(Rot4.East);
			}
			IntVec3[] array = new IntVec3[]
			{
				this.GetPositionFromRelativeRotation(Rot4.West),
				this.GetPositionFromRelativeRotation(Rot4.North)
			};
			int num = Math.Max(0, Array.FindIndex<IntVec3>(array, (IntVec3 dir) => dir == this._splitterDest));
			if (this._mythingID == thing.ThingID && this.IsFreeBelt(this._splitterDest))
			{
				return this._splitterDest;
			}
			this._mythingID = thing.ThingID;
			num = (num + 1) % 2;
			if (this.IsFreeBelt(array[num]))
			{
				this._splitterDest = array[num];
				return this._splitterDest;
			}
			num = (num + 1) % 2;
			if (this.IsFreeBelt(array[num]))
			{
				this._splitterDest = array[num];
				return this._splitterDest;
			}
			return this._splitterDest;
		}
		private bool IsFreeBelt(IntVec3 position)
		{
			BeltComponent beltComponent = position.GetBeltComponent(base.BeltLevel);
			return beltComponent != null && beltComponent.CanAcceptFrom(this, false);
		}
	}
}
