using A2B;
using RimWorld;
using System;
using Verse;
namespace A2B_Selector
{
	public class Opposite : BeltComponent
	{
		private Rot4 nextDest = Rot4.East;
		private bool hasStorageSettings;
		public override void PostExposeData()
		{
			base.PostExposeData();
			Scribe_Values.LookValue<bool>(ref this.hasStorageSettings, "hasStorageSettings", false, false);
		}
		public override void PostSpawnSetup()
		{
			base.PostSpawnSetup();
			ISlotGroupParent slotGroupParent = this.parent as ISlotGroupParent;
			if (slotGroupParent == null)
			{
				throw new InvalidOperationException("parent is not a SlotGroupParent!");
			}
			if (!this.hasStorageSettings)
			{
				slotGroupParent.GetStoreSettings().filter.SetDisallowAll();
			}
			this.hasStorageSettings = true;
		}
		public override bool CanAcceptFrom(Rot4 direction)
		{
			return direction == Rot4.South || direction == Rot4.North;
		}
		public override IntVec3 GetDestinationForThing(Thing thing)
		{
			ISlotGroupParent slotGroupParent = this.parent as ISlotGroupParent;
			if (slotGroupParent == null)
			{
				throw new InvalidOperationException("parent is not a SlotGroupParent!");
			}
			StorageSettings storeSettings = slotGroupParent.GetStoreSettings();
			if (storeSettings.AllowedToAccept(thing))
			{
				return this.GetPositionFromRelativeRotation(Rot4.West);
			}
			return this.GetPositionFromRelativeRotation(Rot4.East);
		}
		private bool IsFreeBelt(IntVec3 position)
		{
			BeltComponent beltComponent = position.GetBeltComponent(base.BeltLevel);
			return beltComponent != null && beltComponent.CanAcceptFrom(this, false);
		}
	}
}
