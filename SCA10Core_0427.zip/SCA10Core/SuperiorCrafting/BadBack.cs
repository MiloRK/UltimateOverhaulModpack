﻿using System;
using System.Linq;
using System.Collections.Generic;
using RimWorld;
using Verse;
using UnityEngine;

namespace SuperiorCrafting
{
    class Recipe_RelocateBadSpine : Recipe_MedicalOperation
    {

        public override void
            ApplyOnPawn(Verse.Pawn pawn, Verse.RecipeDef recipe, BodyPartRecord part, Verse.Pawn billDoer)
        {
            base.ApplyOnPawn(pawn, recipe, part, billDoer);
            if (!pawn.health.hediffSet.HasHediff(HediffDefOf.BadBack))
                return;
            foreach (Hediff hediff in
                     pawn.health.hediffSet.GetHediffs<Hediff>())
            {
                if (hediff.def == HediffDefOf.BadBack &&
                    part.def == hediff.Part.def)
                {
                    pawn.health.hediffSet.hediffs.Remove(hediff);
                    new HediffWorker_BadSpine().TryApplyBecauseOfAge(pawn);
                    break;
                }
            }
            return;
        }

        public override System.Collections.Generic.IEnumerable<BodyPartRecord>
            GetPartsToApplyOn(Pawn pawn, RecipeDef recipe)
        {
            List<BodyPartDef> appliableParts = recipe.appliedOnFixedBodyParts;
            Hediff hediff = pawn.health.hediffSet.GetFirstHediffOfDef(HediffDefOf.BadBack);
            if (hediff != null && appliableParts.Contains(hediff.Part.def))
            {
                yield return hediff.Part;
            }
            yield break;
        }
    }


    class HediffWorker_BadSpine : HediffWorker
    {
        public override bool TryApplyBecauseOfAge(Pawn pawn)
        {
            if (pawn.health.hediffSet.HasHediff(HediffDefOf.BadBack))
            {
                return false;
            }
            BodyPartRecord bodyPartRecord = null;
            bodyPartRecord = (
                from x in pawn.health.hediffSet.GetNotMissingParts(null, null)
                where !pawn.health.hediffSet.PartOrAnyAncestorHasDirectlyAddedParts(x) && x.def.defName == "Spine"
                select x).FirstOrDefault<BodyPartRecord>();
            if (bodyPartRecord != null)
            {
                pawn.health.AddHediff(HediffDefOf.BadBack, bodyPartRecord, null);
                return true;
            }
            return false;
        }
    }
}