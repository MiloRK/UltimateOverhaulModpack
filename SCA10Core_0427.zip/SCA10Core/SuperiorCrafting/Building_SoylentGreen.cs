﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using RimWorld;
using Verse;
using VerseBase;

namespace SuperiorCrafting
{
    class Building_SoylentGreen : Building_WorkTable
    {
        public CompPowerTrader powerComp;
        public CompGlower glowerComp;
        private int pufferSmoke;
        private static readonly Material IconOn = MaterialPool.MatFrom("Things/Building/SCMisc/SoylentGreenOn");
        private static readonly Material IconOff = MaterialPool.MatFrom("Things/Building/SCMisc/SoylentGreenOff");

        public bool IsFlareActive
        {
            get
            {
                return !Find.MapConditionManager.ConditionIsActive(MapConditionDefOf.SolarFlare);
            }
        }
        public bool isPowered
        {
            get
            {
                return this.powerComp.PowerOn && IsFlareActive;
            }
        }
        public override Material DrawMat(IntRot rot)
        {
            return (isPowered) ? Building_SoylentGreen.IconOn : Building_SoylentGreen.IconOff;
        }
        public override void SpawnSetup()
        {
            base.SpawnSetup();
            powerComp = base.GetComp<CompPowerTrader>();
            glowerComp = base.GetComp<CompGlower>();
            glowerComp.Lit = false;
        }
        public override void Tick()
        {
            base.Tick();
            this.pufferSmoke--;
            if (!this.isPowered)
            {
                glowerComp.Lit = false;
                this.powerComp.powerOutput = 0f;
            }
            else
                if (pufferSmoke <= 0)
                {
                    MoteMaker.TryThrowSmoke(this.TrueCenter(), 2f);
                    pufferSmoke = 120;
                }
        }
    }
}