﻿using System;
using Verse;
using RimWorld;
namespace SuperiorCrafting
{
    public class Alert_SteamGeneratorNeedsHopper : Alert_High
    {
        public override AlertReport Report
        {
            get
            {
                foreach (Building_SteamGenerator current in Find.ListerBuildings.AllBuildingsColonistOfClass<Building_SteamGenerator>())
                {
                    bool flag = false;
                    ThingDef thingDef = ThingDef.Named("GenHopper");
                    foreach (IntVec3 current2 in GenAdj.CellsAdjacentCardinal(current))
                    {
                        Thing edifice = current2.GetEdifice();
                        if (edifice != null && edifice.def == thingDef)
                        {
                            flag = true;
                            break;
                        }
                    }
                    if (!flag)
                    {
                        return AlertReport.CulpritIs(current);
                    }
                }
                return AlertReport.Inactive;
            }
        }
        public Alert_SteamGeneratorNeedsHopper()
        {
            this.baseLabel = "NeedGeneratorHopper".Translate();
            this.baseExplanation = "NeedGeneratorHopperDesc".Translate();
        }
    }
}
