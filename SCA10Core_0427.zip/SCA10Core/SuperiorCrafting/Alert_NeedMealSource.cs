﻿using System;
using System.Linq;
using Verse;
namespace RimWorld
{
    public class Alert_NeedMealSource_SC : Alert_NeedMealSource
    {
        private static ThingDef TableGrill;
        public override AlertReport Report
        {
            get
            {
                AlertReport result;
                if (GenDate.DaysPassed < 2)
                {
                    result = false;
                }
                else
                {
                    if (Find.ListerBuildings.allBuildingsColonist.Any((Building b) => b.def == ThingDefOf.NutrientPasteDispenser || b.def == ThingDefOf.CookStove || !(b.def.ToString() != "TableButcher") || !(b.def.ToString() != "TableGrill")))
                    {
                        result = false;
                    }
                    else
                    {
                        result = true;
                    }
                }
                return result;
            }
        }
    }
}