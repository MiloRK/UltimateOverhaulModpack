﻿using System;
using Verse;
using UnityEngine;
using RimWorld;

public class Building_SmallSolar : Building_PowerPlant
{
    public const float FullSunPower = 500;
    public const float NightPower = 0f;
    private static readonly Vector2 BarSize = new Vector2(0.65f, 0.07f);
    private static readonly Material BarFilledMat = SolidColorMaterials.SimpleSolidColorMaterial(new Color(0.5f, 0.475f, 0.1f));
    private static readonly Material BarUnfilledMat = SolidColorMaterials.SimpleSolidColorMaterial(new Color(0.15f, 0.15f, 0.15f));
    public override void Tick()
    {
        base.Tick();
        if (Find.RoofGrid.Roofed(base.Position))
        {
            this.powerComp.PowerOutput = 0f;
        }
        else
        {
            this.powerComp.PowerOutput = Mathf.Lerp(0f, 500, SkyManager.CurSkyGlow);
        }
    }
    public override void Draw()
    {
        base.Draw();
            GenDraw.FillableBarRequest r = default(GenDraw.FillableBarRequest);
            r.center = this.DrawPos + Vector3.left * 0.36f;
            r.size = Building_SmallSolar.BarSize;
            r.fillPercent = this.powerComp.PowerOutput / 500f;
            r.filledMat = Building_SmallSolar.BarFilledMat;
            r.unfilledMat = Building_SmallSolar.BarUnfilledMat;
            r.margin = 0.08f;
            Rot4 rotation = base.Rotation;
            rotation.Rotate(RotationDirection.Clockwise);
            r.rotation = rotation;
            GenDraw.DrawFillableBar(r);
    }
}
