﻿using SuperiorCrafting;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using UnityEngine;
using Verse;
using RimWorld;
namespace SuperiorCrafting
{
    public static class SCUpgrades
    {
        public static void AgricultureI()
        {
            DefDatabase<ThingDef>.GetNamed("PlantCorn").plant.sowTags.Add("Ground");
            DefDatabase<ThingDef>.GetNamed("PlantRice").plant.sowTags.Add("Ground");
            DefDatabase<ThingDef>.GetNamed("PlantRice").plant.sowTags.Add("Hydroponic");
            DefDatabase<ThingDef>.GetNamed("PlantStrawberry").plant.sowTags.Add("Ground");
            DefDatabase<ThingDef>.GetNamed("PlantStrawberry").plant.sowTags.Add("Hydroponic");
        }
        public static void Brewing()
        {
            DefDatabase<ThingDef>.GetNamed("PlantHops").plant.sowTags.Add("Ground");
            DefDatabase<ThingDef>.GetNamed("PlantHops").plant.sowTags.Add("Hydroponic");
        }
        public static void ConstructionI()
        {
            DefDatabase<ThingDef>.GetNamed("SCWall").stuffCategories.Add(DefDatabase<StuffCategoryDef>.GetNamed("Metallic"));
            DefDatabase<ThingDef>.GetNamed("SCWall").stuffCategories.Add(DefDatabase<StuffCategoryDef>.GetNamed("Stony"));
            DefDatabase<ThingDef>.GetNamed("Door").stuffCategories.Add(DefDatabase<StuffCategoryDef>.GetNamed("Metallic"));
            DefDatabase<ThingDef>.GetNamed("SCWall").SetStatBaseValue(StatDef.Named("MaxHitPoints"), 250);
        }
        public static void ConstructionII()
        {
            DefDatabase<ThingDef>.GetNamed("SCWall").SetStatBaseValue(StatDef.Named("MaxHitPoints"), 275);
        }
        public static void ConstructionIII()
        {
            DefDatabase<ThingDef>.GetNamed("SCWall").SetStatBaseValue(StatDef.Named("MaxHitPoints"), 300);
        }
        public static void ConstructionIV()
        {
            DefDatabase<ThingDef>.GetNamed("SCWall").SetStatBaseValue(StatDef.Named("MaxHitPoints"), 325);
        }
        public static void CraftingI()
        {
            DefDatabase<ThingDef>.GetNamed("PlantCotton").plant.sowTags.Add("Ground");
            DefDatabase<ThingDef>.GetNamed("PlantCotton").plant.sowTags.Add("Hydroponic");
            DefDatabase<ThingDef>.GetNamed("PlantDevilstrand").plant.sowTags.Add("Ground");
            DefDatabase<ThingDef>.GetNamed("PlantDevilstrand").plant.sowTags.Add("Hydroponic");
        }
        public static void HospitalBed()
        {
            DefDatabase<ThingDef>.GetNamed("PlantXerigium").plant.sowTags.Add("Ground");
            DefDatabase<ThingDef>.GetNamed("PlantXerigium").plant.sowTags.Add("Hydroponic");
        }
        public static void PowerII()
        {
            DefDatabase<ThingDef>.GetNamed("Battery").comps.First<CompProperties>().efficiency = .65f;
        }
        public static void PowerIII()
        {
            DefDatabase<ThingDef>.GetNamed("Battery").comps.First<CompProperties>().efficiency = .80f;
        }
        public static void PowerIV()
        {
            DefDatabase<ThingDef>.GetNamed("Battery").comps.First<CompProperties>().efficiency = .95f;
        }
        public static void NutrientResynthesisII()
        {
            DefDatabase<ThingDef>.GetNamed("NutrientPasteDispenser").building.foodCostPerDispense = 6;
        }
        public static void ProteinReplication()
        {
            ThingDefOf.MealNutrientPaste = ThingDefOf.MealSimple;
        }
    }
}